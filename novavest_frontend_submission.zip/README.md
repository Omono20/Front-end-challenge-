# NovaVest Frontend

A polished responsive investment-challenge frontend concept.

## Open
Double-click `index.html` or open it in any modern browser.

## Features
- Responsive dark-mode landing page
- Portfolio dashboard
- Challenge progress section
- Leaderboard
- Interactive investment growth calculator
- Join/sign-in modal
- No external dependencies

## Submission note
This is a front-end prototype only. The form is a visual demo and is not connected to a backend.
